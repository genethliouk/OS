#!/bin/bash
date

current_time=$(date +%s)
echo "Current time: $current_time" 
let double_time=current_time*2
echo $double_time 
for i in {1..20}; do
	echo "$i"
done
